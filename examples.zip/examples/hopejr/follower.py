from lerobot.common.robot_devices.motors.feetech import (
    CalibrationMode,
    FeetechMotorsBus,
)
import yaml

class HopeJuniorRobot:
    def __init__(self):
        self.arm_port = "/dev/ttyUSB0"
        self.hand_port = "/dev/ttyACM0"
        self.arm_bus = FeetechMotorsBus(
            port = self.arm_port,
            motors={
                # "motor1": (1, "sts3250"),
                # "motor2": (2, "sts3250"),
                # "motor3": (3, "sts3250"),
                
                #"shoulder_pitch": [1, "sts3215"],
                "shoulder_pitch": [1, "sm8512bl"],
                "shoulder_yaw": [2, "sts3250"],  # TODO: sts3250
                "shoulder_roll": [3, "sts3250"],  # TODO: sts3250
                "elbow_flex": [4, "sts3250"],
                "wrist_roll": [5, "sts3215"],
                "wrist_yaw": [6, "sts3215"],
                "wrist_pitch": [7, "sts3215"],
            },
            protocol_version=0,
        )
        self.hand_bus = FeetechMotorsBus(
            port=self.hand_port,
            motors={
                "thumb_basel_rotation": [25, "scs0009"],# 950 - 650 ok
                "thumb_flexor": [27, "scs0009"],# 0 - 500 ok
                "thumb_pinky_side": [26, "scs0009"],# 0 -700 ok
                "thumb_thumb_side": [30, "scs0009"],# 300 -800 ok
                "index_flexor": [28, "scs0009"],# 600 - 950 ok
                "index_pinky_side": [38, "scs0009"],#100- 450 ok
                "index_thumb_side": [37, "scs0009"],# 50 - 600 ok
                "middle_flexor": [22, "scs0009"],# 150 -900 ok
                "middle_pinky_side": [23, "scs0009"],# 750 - 950 ok
                "middle_thumb_side": [35, "scs0009"],# 600 -950 ok
                "ring_flexor": [32, "scs0009"],# 150 - 950 ok
                "ring_pinky_side": [33, "scs0009"],# 600 -900 ok
                "ring_thumb_side": [36, "scs0009"],# 150 -500 ok
                "pinky_flexor": [31, "scs0009"],# 500 - 950 ok
                "pinky_pinky_side": [34, "scs0009"],# 500 -900 ok
                "pinky_thumb_side": [21, "scs0009"],# 100 -550
            },#spare servo is id 24
            protocol_version=1,#1
            group_sync_read=False,
        )

        self.arm_calib_dict = self.get_arm_calibration()
        self.hand_calib_dict = self.get_hand_calibration()

    def apply_arm_config(self, config_file):
        with open(config_file, "r") as file:
            config = yaml.safe_load(file)
        for param, value in config.get("robot", {}).get("arm_bus", {}).items():
            self.arm_bus.write(param, value)

    def apply_hand_config(config_file, robot):
        with open(config_file, "r") as file:
            config = yaml.safe_load(file)

        for param, value in config.get("robot", {}).get("hand_bus", {}).items():
            robot.arm_bus.write(param, value)

    def get_hand_calibration(self):
        homing_offset = [0] * len(self.hand_bus.motor_names)
        drive_mode = [0] * len(self.hand_bus.motor_names)
        start_pos = [
            150,  # thumb_basel_rotation
            200,    # thumb_flexor
            0,    # thumb_pinky_side
            300,  # thumb_thumb_side
            600,  # index_flexor
            100,  # index_pinky_side
            50,   # index_thumb_side
            250,  # middle_flexor
            800,  # middle_pinky_side
            600,  # middle_thumb_side
            150,  # ring_flexor
            600,  # ring_pinky_side
            150,  # ring_thumb_side
            500,  # pinky_flexor
            500,  # pinky_pinky_side
            100,  # pinky_thumb_side
        ]
        end_pos = [
            start_pos[0] - 150,  # thumb_basel_rotation
            start_pos[1] + 300,  # thumb_flexor        
            start_pos[2] + 700,  # thumb_pinky_side      
            start_pos[3] + 500,  # thumb_thumb_side    
            start_pos[4] + 350,  # index_flexor         
            start_pos[5] + 350,  # index_pinky_side    
            start_pos[6] + 550,  # index_thumb_side      
            start_pos[7] + 750,  # middle_flexor        
            start_pos[8] + 200,  # middle_pinky_side     
            start_pos[9] + 350,  # middle_thumb_side   
            start_pos[10] + 800, # ring_flexor          
            start_pos[11] + 300, # ring_pinky_side      
            start_pos[12] + 350, # ring_thumb_side      
            start_pos[13] + 450, # pinky_flexor         
            start_pos[14] + 400, # pinky_pinky_side 
            start_pos[15] + 650, # pinky_thumb_side
        ]

        

        calib_modes = [CalibrationMode.LINEAR.name] * len(self.hand_bus.motor_names)

        calib_dict = {
            "homing_offset": homing_offset,
            "drive_mode": drive_mode,
            "start_pos": start_pos,
            "end_pos": end_pos,
            "calib_mode": calib_modes,
            "motor_names": self.hand_bus.motor_names,
        }
        return calib_dict
    
    def get_arm_calibration(self):

        homing_offset = [0] * len(self.arm_bus.motor_names)
        drive_mode = [0] * len(self.arm_bus.motor_names)

        start_pos = [
            1600,   # shoulder_up
            2450,  # shoulder_forward
            1700,  # shoulder_roll
            1150,  # bend_elbow
            700,  # wrist_roll
            1850,  # wrist_yaw
            1700,  # wrist_pitch
        ]

        end_pos = [
            3100,  # shoulder_up
            3150,  # shoulder_forward
            400,  #shoulder_roll
            2800,  # bend_elbow
            2600,  # wrist_roll
            2150,  # wrist_yaw
            2400,  # wrist_pitch
        ]

        calib_modes = [CalibrationMode.LINEAR.name] * len(self.arm_bus.motor_names)

        calib_dict = {
            "homing_offset": homing_offset,
            "drive_mode": drive_mode,
            "start_pos": start_pos,
            "end_pos": end_pos,
            "calib_mode": calib_modes,
            "motor_names": self.arm_bus.motor_names,
        }
        return calib_dict

    def connect_arm(self):
        self.arm_bus.connect()

    def connect_hand(self):
        self.hand_bus.connect()